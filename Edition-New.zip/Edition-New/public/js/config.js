turnConfig = {
   iceServers: [
   {
   urls: [ "stun:140.138.144.121:3478" ]
   }, 
   {
   username: "wordpress110",
   credential: "0x523d4bd25ee548732a1d0213586e6dad",
   urls: [
       "turn:140.138.144.121:3478",
        ]
   }
 ]
}
